Name & email:
Francisco Rivas		frankie7413@csu.fullerton.edu
Tommy Phan 		tommyphan8@csu.fullerton.edu
Linh Cao 		linhcao@csu.fullerton.edu

Language: C++
How to execute: ./sender dog.jpeg & ./recv
Extra credit: N/A
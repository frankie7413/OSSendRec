#!/bin/bash

sleep 10&
sleep 10&
sleep 10&
sleep 10&
sleep 10&
sleep 10&

wait
